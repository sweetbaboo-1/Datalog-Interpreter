//
// Created by Matthew on 7/19/2022.
//

#ifndef CS236_INTERPRETER_H
#define CS236_INTERPRETER_H

#include "DatalogProgram.h"
#include "Database.h"
#include "Relation.h"
#include <iostream>
class Interpreter {
private:
    DatalogProgram datalogProgram;
    Database database;
public:

    explicit Interpreter(const DatalogProgram& datalogProgram) : datalogProgram(datalogProgram) {
        // make a relation for each scheme-predicate and put that relation in the database
        // make a tuple for each fact-predicate and put that tuple in the appropriate relation in the database

        // make a relation for each scheme and add it to the database
        for (Predicate scheme : datalogProgram.getSchemes()) {
            Relation relation;
            relation.setName(scheme.getName());
            Header header;
            for (const Parameter& parameter : scheme.getParameters()) {
                header.push_back(parameter.getValue());
            }
            relation.setHeader(header);
            database.addRelation(relation);
        }

        // make a tuple for each fact and add it to the database
        for (Predicate fact : datalogProgram.getFacts()) {
            Tuple tuple;
            for (const Parameter& parameter : fact.getParameters()) {
                tuple.push_back(parameter.getValue());
            }
            database.addTuple(fact.getName(), tuple);
        }
    }

    void run() {
        //evalSchemes();
        //evalFacts
        // evalRules
        evalQueries();
//        for (auto & it : database.getDatabase())
//            cout << it.second.toString();
    }

    void evalSchemes() {

    }

    void evalFacts() {

    }

    void evalRules() {

    }

    void evalQueries() {
        for (Predicate query : datalogProgram.getQueries()) {
            Relation* result = evalPredicate(query);
            int x = result->numTuples();
            cout << query.toString() << "? " << (result->toString().size() > 0 ? "Yes(" + to_string(x) + ")\n" + result->toString() : "No\n") << "\n";
        }
    }

    bool seen() {

        return false;
    }
    Relation* evalPredicate(Predicate predicate) {
        map<string, unsigned int> seenParameters;
        vector<unsigned int> indexes;
        vector<string> newHeader;

        Relation* output = database.getRelation(predicate.getName());
        unsigned int i = 0;
        for (Parameter parameter : predicate.getParameters()) {
            if (parameter.isConst()) // constant
                output = output->select(i, parameter.getValue());
            else { // variable
                if (seenParameters.find(parameter.getValue()) != seenParameters.end()) { // we've seen this parameter
                    output = output->select(seenParameters.at(parameter.getValue()), i);
                }
                else { // we've not seen the parameter
                    // add parameter to the map
                    seenParameters.insert(pair<string, unsigned int>(parameter.getValue(), i));
                    indexes.push_back(i);
                    newHeader.push_back(parameter.getValue());
                }
            }
            i++;
        }
        output = output->project(indexes);
        output = output->rename(newHeader);
        return output;
    }
};
#endif //CS236_INTERPRETER_H
