#include "Token.h"
#include<iostream>
#include<fstream>
#include<string>
#include "Lexer.h"
#include "Parser.h"
#include "DatalogProgram.h"
#include "Relation.h"
#include "Database.h"
#include "Interpreter.h"

using namespace std;

int main(int argc, char* argv[]) {

    ifstream f(argv[1]);
    string input;
    input.assign((istreambuf_iterator<char>(f)), (istreambuf_iterator<char>()));

    vector<Token> tokens;
    Lexer lexer;
    DatalogProgram datalogProgram;

    tokens = lexer.run(input);

    try {
        Parser parser = Parser(tokens);
        datalogProgram = parser.run();
        cout << "Success!\n";
        cout << datalogProgram.toString();
        cout << "\n\n------------------------------------------------\n\n";
        Interpreter interpreter(datalogProgram);
        interpreter.run();
    }
    catch(Token errorToken) {
        cout << "Failure!" << endl << "  " << errorToken.toString();
    }
    catch(const char* errorMsg) {
        cout << errorMsg;
    }
}
//
//int main() {
//    Tuple t1;
//    t1.push_back("A");
//    t1.push_back("B");
//    t1.push_back("C");
//
//    Tuple t2;
//    t2.push_back("1");
//    t2.push_back("2");
//    t2.push_back("1");
//
//    Header h1;
//    h1.push_back("col0");
//    h1.push_back("col1");
//    h1.push_back("col2");
//
//    Relation r1;
//    r1.setName("first");
//    r1.setHeader(h1);
//    r1.addTuple(t1);
//    r1.addTuple(t2);
//
//    cout << r1.toString() << endl;
//
//}
