//
// Created by Matthew on 7/15/2022.
//

#ifndef CS236_RELATION_H
#define CS236_RELATION_H

#include "Header.h"
#include "Tuple.h"
#include <set>
class Relation {
private:
    string name;
    Header header;
    set<Tuple> tuples;

public:
    Relation() { }

    Relation* select(unsigned int col, string expectedVal) {
        Relation* output = new Relation(); // make a new empty relation

        output->setName(this->name); // copy over name
        output->setHeader(this->header); // copy over header

        for (Tuple currTuple : this->tuples) { // loop through each tuple
            if (currTuple.at(col) == expectedVal) {
                output->addTuple(currTuple);
            }
        }
        return output;
    }

    Relation* select(unsigned int col1, unsigned int col2) {
        // check to make sure both columns are in bounds
        if (tuples.size() <= col1)
            throw "ERROR: Tried to select col that is out of range";
        if (tuples.size() <= col2)
            throw "ERROR: Tried to select col that is out of range";
        Relation* output = new Relation(); // make a new empty relation

        output->setName(this->name); // copy over name
        output->setHeader(this->header); // copy over header

        for (Tuple currTuple : this->tuples) { // loop through each tuple
            if (currTuple.at(col1) == currTuple.at(col2)) {
                output->addTuple(currTuple);
            }
        }
        return output;
    }

    Relation* project(vector<unsigned int> colsToKeep) {
        Relation* output = new Relation();
        output->setName(name);
        Header newHeader;
        for (unsigned int i: colsToKeep) {
            newHeader.push_back(header.at(i));
        }
        output->setHeader(newHeader);

        set<Tuple> newTuples;
        for (Tuple t: tuples) {
            Tuple tuple;
            for (int i: colsToKeep) {
                tuple.push_back(t.at(i));
            }
            newTuples.insert(tuple);
        }
        output->setTuples(newTuples);
        return output;
    }

    void setTuples(set<Tuple> set1) {
        tuples = set1;
    }

    Relation* rename(vector<string> newAttributes) {
        Relation* output = new Relation();
        output->setName(name);
        Header newHeader = (Header(newAttributes));
        output->setHeader(newHeader);
        output->setTuples(tuples);
        return output;
    }

    void addTuple(Tuple t) {
        tuples.insert(t);
    }

    unsigned int numTuples() const {
        return tuples.size();
    }

    string toString() const {
        stringstream out;
        //out << name;
        for (Tuple t : tuples) {
            if (t.size() > 0) {
                out << "  " << t.toString(header) << endl;
            }
        }
        return out.str();
    }

    const string &getName() const {
        return name;
    }

    void setName(const string &name) {
        Relation::name = name;
    }

    const Header &getHeader() const {
        return header;
    }

    void setHeader(const Header &header) {
        Relation::header = header;
    }
};

#endif //CS236_RELATION_H
