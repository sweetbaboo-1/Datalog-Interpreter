//
// Created by Matthew on 6/29/2022.
//

#ifndef CS236_PARSER_H
#define CS236_PARSER_H

#include <vector>
#include <iostream>
#include "Token.h"


class Parser {
private:
    vector<Token> tokens;
    unsigned int currTokenIndex = 0;

    public:
    Parser(const vector<Token>& tokens) : tokens(tokens) { }
    TokenType tokenType() const {
        if (currTokenIndex >= tokens.size()) return UNDEFINED;
        return tokens.at(currTokenIndex).getType();
    }
    void advanceToken() {
        ++currTokenIndex;
    }
    void throwError() {
        if (currTokenIndex >= tokens.size()) throw tokens.at(tokens.size() - 1);
        throw tokens.at(currTokenIndex);
    }
    void match(TokenType expectedType) {
        if (tokenType() == expectedType) {
            advanceToken();
        } else {
            throwError();
        }
    }

    // datalogProgram -> SCHEMES COLON scheme schemeList FACTS COLON factList RULES COLON ruleList QUERIES COLON query queryList EOF
    void datalogProgram() {
        if(tokenType()==SCHEMES){
            match(SCHEMES);
            match(COLON);
            scheme();
            schemeList();
            match(FACTS);
            match(COLON);
            factList();
            match(RULES);
            match(COLON);
            ruleList();
            match(QUERIES);
            match(COLON);
            query();
            queryList();
            match(END_OF_FILE);
        } else {
            // lambda
        }
    }

    // schemeList -> scheme schemeList | lambda
    void schemeList() {
        if (tokenType() == ID) {
            scheme();
            schemeList();
        } else {
            // lambda
        }
    }

    // factList	-> fact factList | lambda
    void factList() {
        if(tokenType() == ID) {
            fact();
            factList();
        } else {
            // lambda
        }
    }

    // ruleList -> rule ruleList | lambda
    void ruleList() {
        if(tokenType() == ID) {
          rule();
          ruleList();
        } else {
            // lambda
        }
    }

    //queryList	-> query queryList | lambda
    void queryList() {
        if(tokenType() == ID) {
            query();
            queryList();
        } else {
            // lambda
        }
    }

    // scheme ->ID LEFT_PAREN ID idList RIGHT_PAREN
    void scheme() {
        match(ID);
        match(LEFT_PAREN);
        match(ID);
        idList();
        match(RIGHT_PAREN);
    }

    // fact -> ID LEFT_PAREN STRING stringList RIGHT_PAREN PERIOD
    void fact() {                                                                       // passed test
        match(ID);
        match(LEFT_PAREN);
        match(STRING);
        stringList();
        match(RIGHT_PAREN);
        match(PERIOD);
    }

    // rule -> headPredicate COLON_DASH predicate predicateList PERIOD
    void rule() {
        if (tokenType() == ID) {
            headPredicate();
            match(COLON_DASH);
            predicate();
            predicateList();
            match(PERIOD);
        }
    }

    // query -> predicate Q_MARK
    void query() {
        if (tokenType() == ID) {
            predicate();
            match(Q_MARK);
        }
    }

    // headPredicate ->	ID LEFT_PAREN ID idList RIGHT_PAREN
    void headPredicate() {
        match(ID);
        match(LEFT_PAREN);
        match(ID);
        idList();
        match(RIGHT_PAREN);
    }

    // predicate ->	ID LEFT_PAREN parameter parameterList RIGHT_PAREN
    void predicate() {
        match(ID);
        match(LEFT_PAREN);
        parameter();
        parameterList();
        match(RIGHT_PAREN);
    }

    // predicateList ->	COMMA predicate predicateList | lambda
    void predicateList() {
        if(tokenType() == COMMA) {
            match(COMMA);
            predicate();
            predicateList();
        } else {
            // lambda
        }
    }

    // parameterList ->	COMMA parameter parameterList | lambda
    void parameterList() {
        if(tokenType() == COMMA) {
            match(COMMA);
            parameter();
            parameterList();
        } else {
            // lambda
        }
    }

    // stringList -> COMMA STRING stringList | lambda
    void stringList() {
        if(tokenType() == COMMA) {
            match(COMMA);
            match(STRING);
            stringList();
        } else {
            // lambda
        }
    }

    // idList -> COMMA ID idList | lambda
    void idList() {
        if (tokenType() == COMMA) { // this is needed b/c of the | lambda
            match(COMMA);
            match(ID);
            idList();
        } else {
            // lambda
        }
    }

    // parameter -> STRING | ID
    void parameter() {
        if(tokenType() == STRING) {
            match(STRING);
        } else {
            match(ID);
        }
    }
};

#endif //CS236_PARSER_H
