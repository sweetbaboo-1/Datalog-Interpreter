#include "Token.h"
#include<iostream>
#include<fstream>
#include<string>
#include "Lexer.h"
using namespace std;

int main(int argc, char* argv[]) {

    ifstream f(argv[1]);
    string input;
    input.assign((istreambuf_iterator<char>(f)), (istreambuf_iterator<char>()));

    vector<Token> tokens;
    Lexer lexer;
    tokens = lexer.run(input);
    cout << "Total Tokens = " << tokens.size();
    return 0;
}